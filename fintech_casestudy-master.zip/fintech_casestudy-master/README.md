# fintech_casestudy
New repo for class
